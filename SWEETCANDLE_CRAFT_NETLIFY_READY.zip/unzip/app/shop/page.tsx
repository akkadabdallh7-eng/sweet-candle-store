'use client';
import { useMemo } from 'react';
import { useSearchParams } from 'next/navigation';
import ProductCard from '../../components/ProductCard';
import { useCatalog } from '../../components/CatalogProvider';
function norm(v:string){return v.toLowerCase().replace(/[إأآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').trim()}
export default function Shop(){const {products}=useCatalog(); const q=useSearchParams(); const cat=q.get('category'); const custom=q.get('custom'); const term=norm(q.get('q')||''); const list=useMemo(()=>products.filter(p=>{const hay=norm(`${p.name} ${p.description} ${p.category} ${p.occasions.join(' ')} ${p.scents.join(' ')}`); return (!cat||p.category===cat)&&(!term||hay.includes(term))&&(!custom||p.category==='منتجات مخصصة')&&p.stock>0}),[cat,term,custom]); return <main><div className="page-head"><div className="eyebrow">SHOP · SWEETCANDLE.CRAFT</div><h1>المتجر</h1><p>اختيارات صُنعت لتقول ما تعجز الكلمات عن قوله.</p></div><div className="toolbar"><span className="pill">{list.length} منتج</span><span className="pill">متوفر الآن</span><span className="pill">دعم عربي وRTL</span></div><section className="section" style={{marginTop:0}}><div className="grid">{list.map(p=><ProductCard key={p.id} p={p}/>)}</div>{!list.length&&<div className="empty">لم نجد منتجات مطابقة حاليًا.</div>}</section></main>}
