import { NextResponse } from 'next/server';
export async function GET(){return NextResponse.json({success:true,data:[{code:'USD',symbol:'$',decimalPlaces:2,position:'before',isDefault:true},{code:'SYP',symbol:'ل.س',decimalPlaces:0,position:'after',isDefault:false}],meta:{exchangeRate:12500}})}
