import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
export async function POST(req: Request){
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL, key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
 if(!url||!key)return NextResponse.json({success:false,error:'Supabase is not configured'},{status:503});
 const auth=req.headers.get('authorization'); if(!auth?.startsWith('Bearer '))return NextResponse.json({success:false,error:'AUTH_REQUIRED'},{status:401});
 const sb=createClient(url,key,{global:{headers:{Authorization:auth}}}); const {data:{user}}=await sb.auth.getUser(); if(!user)return NextResponse.json({success:false,error:'AUTH_REQUIRED'},{status:401});
 const payload=await req.json(); const {data,error}=await sb.rpc('create_order_atomic',{payload}); if(error)return NextResponse.json({success:false,error:error.message},{status:400});
 return NextResponse.json({success:true,data});
}
