import { NextResponse } from 'next/server';
import { supabase } from '../../../lib/supabase';
import { products as fallbackProducts, categories as fallbackCategories, occasions as fallbackOccasions } from '../../../lib/catalog';
export async function GET(){
 if(!supabase)return NextResponse.json({products:fallbackProducts,categories:fallbackCategories,occasions:fallbackOccasions,source:'fallback'});
 const [{data:ps,error:pe},{data:cs},{data:os}]=await Promise.all([
  supabase.from('products').select('*,product_images(image_url,alt_text,sort_order,is_primary),product_categories(category:categories(name_ar)),product_occasions(occasion:occasions(name_ar))').eq('is_active',true).is('deleted_at',null).order('created_at',{ascending:false}),
  supabase.from('categories').select('*').eq('is_active',true).order('sort_order'),
  supabase.from('occasions').select('*').eq('is_active',true).order('sort_order')
 ]);
 if(pe||!ps?.length)return NextResponse.json({products:fallbackProducts,categories:fallbackCategories,occasions:fallbackOccasions,source:'fallback'});
 const mapped=ps.map((p:any)=>({id:p.id,slug:p.slug,name:p.name_ar,description:p.description_ar||'',category:p.product_categories?.[0]?.category?.name_ar||'منتجات',occasions:(p.product_occasions||[]).map((x:any)=>x.occasion?.name_ar).filter(Boolean),image:(p.product_images||[]).sort((a:any,b:any)=>a.sort_order-b.sort_order).find((x:any)=>x.is_primary)?.image_url||(p.product_images||[])[0]?.image_url||'/brand/logo.png',priceUSD:Number(p.base_price_usd),priceSYP:p.manual_syp_price?Number(p.manual_syp_price):undefined,featured:p.is_featured,bestseller:p.is_best_seller,discount:undefined,scents:[],colors:[],stock:Number(p.stock_quantity)}));
 return NextResponse.json({products:mapped,categories:(cs||[]).map((c:any)=>c.name_ar),occasions:(os||[]).map((o:any)=>o.name_ar),source:'supabase'});
}
