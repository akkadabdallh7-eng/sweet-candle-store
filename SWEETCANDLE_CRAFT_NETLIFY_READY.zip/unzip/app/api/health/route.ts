import { NextResponse } from 'next/server';
export async function GET(){return NextResponse.json({success:true,data:{service:'SWEETCANDLE.CRAFT',status:'ok',version:'0.1.0'}})}
