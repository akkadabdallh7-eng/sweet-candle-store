'use client';
import { useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../components/AuthProvider';
export default function Account(){
 const {user,loading,signOut}=useAuth(); const [mode,setMode]=useState<'login'|'signup'>('login'); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [name,setName]=useState(''); const [msg,setMsg]=useState('');
 async function submit(){ if(!supabase){setMsg('أضف إعدادات Supabase أولًا.');return;} setMsg(''); if(mode==='login'){const {error}=await supabase.auth.signInWithPassword({email,password}); if(error)setMsg(error.message)} else {const {error}=await supabase.auth.signUp({email,password,options:{data:{display_name:name}}}); if(error)setMsg(error.message); else setMsg('تم إنشاء الحساب. تحقق من بريدك إذا كان تأكيد البريد مفعّلًا.');}}
 if(loading)return <main><div className="page-head"><h1>جاري التحميل…</h1></div></main>;
 if(user)return <main><section className="section"><div className="panel"><div className="eyebrow">ACCOUNT</div><h1>مرحبًا بك</h1><p>{user.email}</p><div className="row"><a className="cta" href="/orders">طلباتي</a><button className="cta secondary" onClick={signOut}>تسجيل الخروج</button></div></div></section></main>;
 return <main><section className="section"><div className="panel" style={{maxWidth:520,margin:'auto'}}><div className="eyebrow">SWEETCANDLE ACCOUNT</div><h1>{mode==='login'?'تسجيل الدخول':'إنشاء حساب'}</h1>{mode==='signup'&&<input className="pill" placeholder="الاسم" value={name} onChange={e=>setName(e.target.value)}/>}<input className="pill" type="email" placeholder="البريد الإلكتروني" value={email} onChange={e=>setEmail(e.target.value)}/><input className="pill" type="password" placeholder="كلمة المرور" value={password} onChange={e=>setPassword(e.target.value)}/><button className="cta" onClick={submit}>{mode==='login'?'دخول':'إنشاء الحساب'}</button>{msg&&<div className="note">{msg}</div>}<button className="link-btn" onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'ليس لديك حساب؟ إنشاء حساب':'لديك حساب؟ تسجيل الدخول'}</button></div></section></main>
}
