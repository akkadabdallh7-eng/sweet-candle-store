import type { Metadata } from 'next';
import './globals.css';
import Header from '../components/Header';
import Footer from '../components/Footer';
import WhatsApp from '../components/WhatsApp';
import { CurrencyProvider } from '../components/CurrencyProvider';
import { AuthProvider } from '../components/AuthProvider';
import { CartProvider } from '../components/CartProvider';
import { CatalogProvider } from '../components/CatalogProvider';
import PWARegister from '../components/PWARegister';
export const metadata: Metadata = { title:'SWEETCANDLE.CRAFT — كل شمعة تحكي قصة', description:'شموع معطرة وهدايا وتوزيعات للمناسبات', manifest:'/manifest.webmanifest', appleWebApp:{capable:true,title:'SWEETCANDLE.CRAFT',statusBarStyle:'default'} };
export const viewport = { themeColor:'#b7892f', width:'device-width', initialScale:1 };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ar" dir="rtl"><body><PWARegister/><AuthProvider><CartProvider><CurrencyProvider><CatalogProvider><Header/>{children}<WhatsApp/><Footer/></CatalogProvider></CurrencyProvider></CartProvider></AuthProvider></body></html>}
