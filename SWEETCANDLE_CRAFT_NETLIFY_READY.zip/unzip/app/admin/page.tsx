'use client';
import { useEffect, useMemo, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../components/AuthProvider';

const tabs=['overview','orders','products','customers','settings'];
export default function Admin(){
 const {user,loading}=useAuth(); const [tab,setTab]=useState('overview'); const [busy,setBusy]=useState(true); const [message,setMessage]=useState('');
 const [authorized,setAuthorized]=useState<boolean|null>(null); const [stats,setStats]=useState({orders:0,sales:0,customers:0,low:0}); const [orders,setOrders]=useState<any[]>([]); const [products,setProducts]=useState<any[]>([]); const [customers,setCustomers]=useState<any[]>([]); const [rate,setRate]=useState('');
 const load=async()=>{ if(!supabase||!user){setBusy(false);return;} setBusy(true); const {data:ok}=await supabase.rpc('has_any_role',{required_roles:['Owner','Admin','Orders Manager','Products Manager','Marketing Manager']}); setAuthorized(Boolean(ok)); if(!ok){setBusy(false);return;}
   const [{data:o},{data:p},{data:c},{data:r}]=await Promise.all([
    supabase.from('orders').select('id,order_number,total,currency,status,created_at,profiles:profiles(display_name,email)').order('created_at',{ascending:false}).limit(100),
    supabase.from('products').select('id,name_ar,sku,base_price_usd,manual_syp_price,stock_quantity,is_active').order('created_at',{ascending:false}),
    supabase.from('profiles').select('id,display_name,email,phone,created_at').order('created_at',{ascending:false}).limit(200),
    supabase.from('exchange_rates').select('rate').eq('from_currency','USD').eq('to_currency','SYP').order('effective_from',{ascending:false}).limit(1)
   ]); const oo=o??[],pp=p??[],cc=c??[]; setOrders(oo);setProducts(pp);setCustomers(cc);setRate(String(r?.[0]?.rate??''));
   setStats({orders:oo.length,sales:oo.reduce((a,x)=>a+Number(x.total||0),0),customers:cc.length,low:pp.filter(x=>Number(x.stock_quantity||0)<=5).length});setBusy(false);
 };
 useEffect(()=>{load()},[user]);
 async function saveRate(){if(!supabase||!rate)return;setMessage('جارٍ حفظ سعر الصرف…');const {error}=await supabase.from('exchange_rates').update({effective_to:new Date().toISOString()}).eq('from_currency','USD').eq('to_currency','SYP').is('effective_to',null);if(error){setMessage(error.message);return;}const {error:e}=await supabase.from('exchange_rates').insert({from_currency:'USD',to_currency:'SYP',rate:Number(rate)});setMessage(e?e.message:'تم تحديث سعر الصرف بنجاح.');await load()}
 async function status(id:string,status:string){if(!supabase)return;const {error}=await supabase.from('orders').update({status}).eq('id',id);setMessage(error?error.message:'تم تحديث الطلب.');await load()}
 if(loading||busy)return <main><div className="page-head"><h1>جاري تحميل لوحة الإدارة…</h1></div></main>;
 if(!user)return <main><div className="page-head"><h1>يجب تسجيل الدخول</h1><a className="cta" href="/account?next=/admin">تسجيل الدخول</a></div></main>;
 if(authorized===false)return <main><div className="page-head"><h1>لا تملك صلاحية الإدارة</h1><p>هذا القسم مخصص لفريق SWEETCANDLE.CRAFT المخوّل.</p></div></main>; return <main><div className="admin-shell"><div className="admin-top"><div><div className="eyebrow">SWEETCANDLE.CRAFT · ADMIN</div><h1>لوحة التحكم</h1><p className="muted">إدارة المتجر، الطلبات، المنتجات والعملات من مكان واحد.</p></div><div className="pill">{user.email}</div></div>
 <div className="admin-tabs">{tabs.map(t=><button className={tab===t?'active':''} onClick={()=>setTab(t)} key={t}>{({overview:'الرئيسية',orders:'الطلبات',products:'المنتجات',customers:'العملاء',settings:'الإعدادات'} as any)[t]}</button>)}</div>
 {message&&<div className="note">{message}</div>}
 {tab==='overview'&&<><div className="admin-grid">{[['الطلبات',stats.orders],['المبيعات',stats.sales.toFixed(2)],['العملاء',stats.customers],['مخزون منخفض',stats.low]].map(x=><div className="stat" key={x[0]}><span className="eyebrow">{x[0]}</span><strong>{x[1]}</strong></div>)}</div><div className="panel"><h2>آخر الطلبات</h2><OrdersTable orders={orders.slice(0,10)} onStatus={status}/></div></>}
 {tab==='orders'&&<div className="panel"><h2>إدارة الطلبات</h2><OrdersTable orders={orders} onStatus={status}/></div>}
 {tab==='products'&&<div className="panel"><h2>المنتجات والمخزون</h2><div className="table-wrap"><table className="table"><thead><tr><th>المنتج</th><th>SKU</th><th>USD</th><th>SYP</th><th>المخزون</th><th>الحالة</th></tr></thead><tbody>{products.map(p=><tr key={p.id}><td>{p.name_ar}</td><td>{p.sku}</td><td>${Number(p.base_price_usd).toFixed(2)}</td><td>{p.manual_syp_price?Number(p.manual_syp_price).toLocaleString():'تلقائي'}</td><td>{p.stock_quantity}</td><td>{p.is_active?'نشط':'مخفي'}</td></tr>)}</tbody></table></div></div>}
 {tab==='customers'&&<div className="panel"><h2>العملاء</h2><div className="table-wrap"><table className="table"><thead><tr><th>الاسم</th><th>البريد</th><th>الهاتف</th><th>التاريخ</th></tr></thead><tbody>{customers.map(c=><tr key={c.id}><td>{c.display_name||'—'}</td><td>{c.email||'—'}</td><td>{c.phone||'—'}</td><td>{new Date(c.created_at).toLocaleDateString('ar-SY')}</td></tr>)}</tbody></table></div></div>}
 {tab==='settings'&&<div className="panel settings-form"><h2>إعدادات العملة</h2><label>1 USD = <input value={rate} onChange={e=>setRate(e.target.value)} inputMode="decimal"/> SYP</label><button className="cta" onClick={saveRate}>حفظ سعر الصرف</button><p className="muted">كل طلب يحتفظ بسعر الصرف المستخدم لحظة إنشائه.</p></div>}
 </div></main>
}
function OrdersTable({orders,onStatus}:{orders:any[];onStatus:(id:string,s:string)=>void}){return <div className="table-wrap"><table className="table"><thead><tr><th>الطلب</th><th>العميل</th><th>الإجمالي</th><th>العملة</th><th>الحالة</th><th>تغيير</th></tr></thead><tbody>{orders.map(o=><tr key={o.id}><td>{o.order_number}</td><td>{o.profiles?.display_name||o.profiles?.email||'—'}</td><td>{Number(o.total).toLocaleString()}</td><td>{o.currency}</td><td>{o.status}</td><td><select value={o.status} onChange={e=>onStatus(o.id,e.target.value)}><option>NEW</option><option>CONFIRMED</option><option>PREPARING</option><option>READY</option><option>OUT_FOR_DELIVERY</option><option>DELIVERED</option><option>CANCELLED</option></select></td></tr>)}</tbody></table></div>}
