'use client';
import { useCart } from './CartProvider';
import type { Product } from '../lib/types';
export default function AddToCart({product}:{product:Product}){const {add}=useCart();return <button className="cta" style={{width:'100%',justifyContent:'center',border:0,cursor:'pointer'}} onClick={()=>add(product)}>أضف إلى السلة</button>}
