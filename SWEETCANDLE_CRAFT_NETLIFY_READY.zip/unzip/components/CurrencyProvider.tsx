'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import { CurrencyCode } from '../lib/types';
import { formatMoney } from '../lib/money';

type Ctx = { currency: CurrencyCode; setCurrency: (c:CurrencyCode)=>void; money:(usd:number)=>string; rate:number };
const CurrencyContext = createContext<Ctx | null>(null);
export function CurrencyProvider({children}:{children:React.ReactNode}) {
  const [currency,setCurrency] = useState<CurrencyCode>('USD');
  const [rate,setRate] = useState(12500);
  useEffect(()=>{ const c=localStorage.getItem('sc_currency') as CurrencyCode|null; if(c) setCurrency(c); const r=localStorage.getItem('sc_rate'); if(r) setRate(Number(r)); (async()=>{try{const res=await fetch('/api/currencies',{cache:'no-store'}); if(res.ok){const j=await res.json(); if(j.rate) {setRate(Number(j.rate)); localStorage.setItem('sc_rate',String(j.rate));}}}catch{}})(); },[]);
  const change=(c:CurrencyCode)=>{setCurrency(c);localStorage.setItem('sc_currency',c)};
  return <CurrencyContext.Provider value={{currency,setCurrency:change,money:(usd)=>formatMoney(usd,currency,rate),rate}}>{children}</CurrencyContext.Provider>
}
export function useCurrency(){const v=useContext(CurrencyContext); if(!v) throw new Error('CurrencyProvider missing'); return v;}
