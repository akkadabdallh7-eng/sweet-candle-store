'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

type AuthCtx={session:Session|null;user:User|null;loading:boolean;signOut:()=>Promise<void>};
const C=createContext<AuthCtx>({session:null,user:null,loading:true,signOut:async()=>{}});
export function AuthProvider({children}:{children:React.ReactNode}){
 const [session,setSession]=useState<Session|null>(null); const [loading,setLoading]=useState(true);
 useEffect(()=>{ if(!supabase){setLoading(false);return;} supabase.auth.getSession().then(({data})=>{setSession(data.session);setLoading(false)}); const {data}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s)); return()=>data.subscription.unsubscribe(); },[]);
 return <C.Provider value={{session,user:session?.user??null,loading,signOut:async()=>{await supabase?.auth.signOut()}}}>{children}</C.Provider>
}
export const useAuth=()=>useContext(C);
