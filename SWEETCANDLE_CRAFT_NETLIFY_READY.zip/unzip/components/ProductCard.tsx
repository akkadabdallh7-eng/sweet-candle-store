'use client';
import Link from 'next/link';
import { Heart, Plus } from 'lucide-react';
import { Product } from '../lib/types';
import { useCurrency } from './CurrencyProvider';
import { useCart } from './CartProvider';
export default function ProductCard({p}:{p:Product}){const {money}=useCurrency(); const {add}=useCart(); return <article className="product-card"><Link href={`/shop/${p.slug}`} className="product-image"><img src={p.image} alt={p.name}/>{p.discount&&<span className="badge">-{p.discount}%</span>}<button className="heart" aria-label="إضافة للمفضلة" onClick={e=>{e.preventDefault();e.stopPropagation();const k='sc_favorites';const xs=JSON.parse(localStorage.getItem(k)||'[]');localStorage.setItem(k,JSON.stringify(xs.includes(p.id)?xs.filter((x:string)=>x!==p.id):[...xs,p.id]));}}><Heart size={18}/></button></Link><div className="product-info"><span className="eyebrow">{p.category}</span><h3>{p.name}</h3><p>{p.description}</p><div className="product-row"><strong>{p.priceUSD?money(p.priceUSD):'حسب التخصيص'}</strong><button className="add" aria-label="إضافة للسلة" onClick={()=>add(p)}><Plus size={18}/></button></div></div></article>}
