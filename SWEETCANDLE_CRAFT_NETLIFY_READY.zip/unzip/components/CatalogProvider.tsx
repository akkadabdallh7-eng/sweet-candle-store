'use client';
import {createContext,useContext,useEffect,useState} from 'react';
import type {Product} from '../lib/types';
import {products as fallbackProducts,categories as fallbackCategories,occasions as fallbackOccasions} from '../lib/catalog';
type Ctx={products:Product[];categories:string[];occasions:string[];loading:boolean};
const C=createContext<Ctx>({products:fallbackProducts,categories:fallbackCategories,occasions:fallbackOccasions,loading:false});
export function CatalogProvider({children}:{children:React.ReactNode}){const [data,setData]=useState<Ctx>({products:fallbackProducts,categories:fallbackCategories,occasions:fallbackOccasions,loading:true});useEffect(()=>{fetch('/api/catalog',{cache:'no-store'}).then(r=>r.json()).then(j=>setData({products:j.products||fallbackProducts,categories:j.categories||fallbackCategories,occasions:j.occasions||fallbackOccasions,loading:false})).catch(()=>setData({products:fallbackProducts,categories:fallbackCategories,occasions:fallbackOccasions,loading:false}))},[]);return <C.Provider value={data}>{children}</C.Provider>}
export const useCatalog=()=>useContext(C);
