'use client';
import { useCurrency } from './CurrencyProvider';
export default function CurrencySwitcher(){const {currency,setCurrency}=useCurrency(); return <button className="currency" onClick={()=>setCurrency(currency==='USD'?'SYP':'USD')} aria-label="تبديل العملة">{currency==='USD'?'$ USD':'🇸🇾 SYP'}</button>}
