'use client';
import {createContext,useContext,useEffect,useMemo,useState} from 'react';
import type {Product} from '../lib/types';
type Item={product:Product;quantity:number;customMessage?:string;selectedOptions?:Record<string,string>};
type Ctx={items:Item[];add:(p:Product)=>void;remove:(id:string)=>void;setQty:(id:string,q:number)=>void;clear:()=>void;count:number;subtotalUSD:number};
const C=createContext<Ctx|null>(null);
export function CartProvider({children}:{children:React.ReactNode}){const [items,setItems]=useState<Item[]>([]); useEffect(()=>{try{const x=localStorage.getItem('sc_cart');if(x)setItems(JSON.parse(x))}catch{}},[]); useEffect(()=>{localStorage.setItem('sc_cart',JSON.stringify(items))},[items]); const api=useMemo(()=>({items,add:(p:Product)=>setItems(x=>{const found=x.find(i=>i.product.id===p.id);return found?x.map(i=>i.product.id===p.id?{...i,quantity:i.quantity+1}:i):[...x,{product:p,quantity:1}]}),remove:(id:string)=>setItems(x=>x.filter(i=>i.product.id!==id)),setQty:(id:string,q:number)=>setItems(x=>q<=0?x.filter(i=>i.product.id!==id):x.map(i=>i.product.id===id?{...i,quantity:q}:i)),clear:()=>setItems([]),count:items.reduce((n,i)=>n+i.quantity,0),subtotalUSD:items.reduce((n,i)=>n+i.product.priceUSD*i.quantity,0)}),[items]); return <C.Provider value={api}>{children}</C.Provider>}
export const useCart=()=>{const v=useContext(C);if(!v)throw new Error('CartProvider missing');return v};
