export default function WhatsApp(){return <a className="whatsapp" href="https://wa.me/963994027648" aria-label="تواصل عبر واتساب">WhatsApp</a>}
