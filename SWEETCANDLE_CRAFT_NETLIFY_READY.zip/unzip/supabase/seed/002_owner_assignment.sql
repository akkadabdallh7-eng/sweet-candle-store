-- After creating your owner user in Supabase Authentication, replace USER_UUID below.
-- Run once in Supabase SQL Editor.
DO $$
DECLARE owner_user UUID := '00000000-0000-0000-0000-000000000000';
DECLARE owner_role UUID;
BEGIN
  SELECT id INTO owner_role FROM roles WHERE name='Owner' LIMIT 1;
  IF owner_role IS NULL THEN RAISE EXCEPTION 'Owner role not found'; END IF;
  IF owner_user = '00000000-0000-0000-0000-000000000000' THEN RAISE EXCEPTION 'Replace USER_UUID first'; END IF;
  INSERT INTO user_roles(user_id,role_id) VALUES(owner_user,owner_role) ON CONFLICT DO NOTHING;
END $$;
