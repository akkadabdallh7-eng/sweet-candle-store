-- Optional starter catalog. Run after migrations.
INSERT INTO categories(name_ar,slug,icon,sort_order) VALUES
('شموع معطرة','scented-candles','🕯️',1),('شموع العروس','bride-candles','👰',2),('شموع التخرج','graduation-candles','🎓',3),('هدايا النجاح','success-gifts','🎁',4),('باقات الشموع','candle-bouquets','💐',5),('توزيعات المناسبات','event-favors','🎀',6),('هدايا خاصة','special-gifts','❤️',7),('منتجات مخصصة','custom-products','✨',8)
ON CONFLICT(slug) DO NOTHING;
INSERT INTO occasions(name_ar,slug,icon,sort_order) VALUES
('التخرج','graduation','🎓',1),('الخطوبة','engagement','💍',2),('الزواج','wedding','💒',3),('العروس','bride','👰',4),('أعياد الميلاد','birthdays','🎂',5),('النجاح','success','🎁',6),('ذكرى خاصة','special-memory','❤️',7),('المناسبات الدينية','religious','🌙',8),('المواليد','newborn','👶',9)
ON CONFLICT(slug) DO NOTHING;
INSERT INTO products(sku,name_ar,slug,description_ar,base_price_usd,stock_quantity,low_stock_threshold,preparation_time_days,is_featured,is_best_seller,is_new,is_customizable,pricing_mode)
VALUES
('SC-001','شمعة الورد الذهبي','golden-rose','شمعة عطرية فاخرة بتفاصيل ناعمة وتغليف يليق بالهدايا المميزة.',18,14,3,2,TRUE,TRUE,TRUE,FALSE,'AUTO'),
('SC-002','باقة شموع التخرج','graduation-bouquet','باقة احتفالية مصممة لتوثيق لحظة النجاح بتفاصيل دافئة.',28,8,2,3,TRUE,TRUE,TRUE,FALSE,'AUTO'),
('SC-003','شمعة العروس','bride-candle','تصميم أنيق للعروس، مناسب للهدايا والتوزيعات والاحتفال.',22,10,2,3,TRUE,FALSE,TRUE,FALSE,'AUTO'),
('SC-004','هدية النجاح','success-gift','هدية صغيرة بفكرة كبيرة، قابلة للتخصيص بالاسم والرسالة.',16,22,4,2,TRUE,TRUE,FALSE,TRUE,'AUTO'),
('SC-005','شمعة مخصصة','custom-candle','اصنع شمعتك الخاصة: الاسم، اللون، الرائحة، الحجم والرسالة.',0,999,10,5,TRUE,FALSE,FALSE,TRUE,'AUTO'),
('SC-006','هدية المولود','newborn-gift','تفاصيل لطيفة وناعمة لاستقبال المولود بطريقة لا تُنسى.',20,12,3,2,FALSE,FALSE,TRUE,FALSE,'AUTO')
ON CONFLICT(slug) DO UPDATE SET name_ar=EXCLUDED.name_ar,description_ar=EXCLUDED.description_ar,base_price_usd=EXCLUDED.base_price_usd,stock_quantity=EXCLUDED.stock_quantity;
-- Link starter products to categories and occasions.
INSERT INTO product_categories(product_id,category_id)
SELECT p.id,c.id FROM products p JOIN categories c ON c.slug = CASE p.slug
 WHEN 'golden-rose' THEN 'scented-candles' WHEN 'graduation-bouquet' THEN 'candle-bouquets'
 WHEN 'bride-candle' THEN 'bride-candles' WHEN 'success-gift' THEN 'success-gifts'
 WHEN 'custom-candle' THEN 'custom-products' WHEN 'newborn-gift' THEN 'special-gifts' END
ON CONFLICT DO NOTHING;
INSERT INTO product_occasions(product_id,occasion_id)
SELECT p.id,o.id FROM products p JOIN occasions o ON o.slug = CASE p.slug
 WHEN 'golden-rose' THEN 'special-memory' WHEN 'graduation-bouquet' THEN 'graduation'
 WHEN 'bride-candle' THEN 'bride' WHEN 'success-gift' THEN 'success'
 WHEN 'custom-candle' THEN 'special-memory' WHEN 'newborn-gift' THEN 'newborn' END
ON CONFLICT DO NOTHING;
