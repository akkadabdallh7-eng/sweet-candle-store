-- SWEETCANDLE.CRAFT Phase 2
-- Production backend foundations: public catalog, auth/RBAC helpers and atomic checkout.

-- Seed currencies and default settings safely.
INSERT INTO currencies (code,name_ar,name_en,symbol,decimal_places,position,is_default,is_active)
VALUES
 ('USD','الدولار الأمريكي','US Dollar','$',2,'before',TRUE,TRUE),
 ('SYP','الليرة السورية الجديدة','Syrian Pound','ل.س',0,'after',FALSE,TRUE)
ON CONFLICT (code) DO UPDATE SET is_active=EXCLUDED.is_active;

INSERT INTO currency_settings (default_currency,rounding_mode,rounding_precision,allow_customer_currency_switch,show_dual_currency)
SELECT 'USD','HALF_UP',0,TRUE,FALSE
WHERE NOT EXISTS (SELECT 1 FROM currency_settings);

INSERT INTO store_settings (store_name,tagline,phone,whatsapp,instagram)
SELECT 'SWEETCANDLE.CRAFT','كل شمعة… تحكي قصة ♡','0994027648','+963994027648','https://www.instagram.com/sweetcandle.craft/'
WHERE NOT EXISTS (SELECT 1 FROM store_settings);

INSERT INTO roles(name,description,is_system_role) VALUES
 ('Owner','صلاحيات كاملة',TRUE),
 ('Admin','إدارة المتجر',TRUE),
 ('Orders Manager','إدارة الطلبات',TRUE),
 ('Products Manager','إدارة المنتجات',TRUE),
 ('Marketing Manager','العروض والمحتوى',TRUE)
ON CONFLICT (name) DO NOTHING;

-- Public catalog read policies.
DO $$ BEGIN
  CREATE POLICY currencies_public_select ON currencies FOR SELECT USING (is_active = TRUE);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY exchange_rates_public_select ON exchange_rates FOR SELECT USING (from_currency='USD' AND to_currency='SYP' AND effective_from <= NOW() AND (effective_to IS NULL OR effective_to > NOW()));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY categories_public_select ON categories FOR SELECT USING (is_active = TRUE);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY occasions_public_select ON occasions FOR SELECT USING (is_active = TRUE);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY products_public_select ON products FOR SELECT USING (is_active = TRUE AND deleted_at IS NULL);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_images_public_select ON product_images FOR SELECT USING (EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_videos_public_select ON product_videos FOR SELECT USING (EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_variants_public_select ON product_variants FOR SELECT USING (is_active=TRUE AND EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_options_public_select ON product_options FOR SELECT USING (EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_option_values_public_select ON product_option_values FOR SELECT USING (is_active=TRUE AND EXISTS (SELECT 1 FROM product_options o JOIN products p ON p.id=o.product_id WHERE o.id=option_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_categories_public_select ON product_categories FOR SELECT USING (EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_occasions_public_select ON product_occasions FOR SELECT USING (EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY delivery_zones_public_select ON delivery_zones FOR SELECT USING (is_active=TRUE);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Role helper for server/RLS policies.
CREATE OR REPLACE FUNCTION public.has_role(required_role TEXT)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id
    WHERE ur.user_id=auth.uid() AND r.name=required_role
  );
$$;

CREATE OR REPLACE FUNCTION public.has_any_role(required_roles TEXT[])
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id
    WHERE ur.user_id=auth.uid() AND r.name = ANY(required_roles)
  );
$$;

-- Admin read/write policies. Owner/Admin can manage everything; module managers get scoped access.
DO $$ BEGIN
  CREATE POLICY products_admin_all ON products FOR ALL USING (has_any_role(ARRAY['Owner','Admin','Products Manager'])) WITH CHECK (has_any_role(ARRAY['Owner','Admin','Products Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY categories_admin_all ON categories FOR ALL USING (has_any_role(ARRAY['Owner','Admin','Products Manager'])) WITH CHECK (has_any_role(ARRAY['Owner','Admin','Products Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY occasions_admin_all ON occasions FOR ALL USING (has_any_role(ARRAY['Owner','Admin','Marketing Manager'])) WITH CHECK (has_any_role(ARRAY['Owner','Admin','Marketing Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_images_admin_all ON product_images FOR ALL USING (has_any_role(ARRAY['Owner','Admin','Products Manager'])) WITH CHECK (has_any_role(ARRAY['Owner','Admin','Products Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_variants_admin_all ON product_variants FOR ALL USING (has_any_role(ARRAY['Owner','Admin','Products Manager'])) WITH CHECK (has_any_role(ARRAY['Owner','Admin','Products Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY delivery_zones_admin_all ON delivery_zones FOR ALL USING (has_any_role(ARRAY['Owner','Admin','Orders Manager'])) WITH CHECK (has_any_role(ARRAY['Owner','Admin','Orders Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY exchange_rates_admin_all ON exchange_rates FOR ALL USING (has_any_role(ARRAY['Owner','Admin'])) WITH CHECK (has_any_role(ARRAY['Owner','Admin']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY currency_settings_admin_all ON currency_settings FOR ALL USING (has_any_role(ARRAY['Owner','Admin'])) WITH CHECK (has_any_role(ARRAY['Owner','Admin']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY store_settings_admin_all ON store_settings FOR ALL USING (has_any_role(ARRAY['Owner','Admin','Marketing Manager'])) WITH CHECK (has_any_role(ARRAY['Owner','Admin','Marketing Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Atomic checkout. Input JSON: {currency, payment_method, delivery_zone_id, shipping_address, customer_notes, coupon_code, items:[{product_id,variant_id,quantity,selected_options,custom_message}]}
CREATE OR REPLACE FUNCTION public.create_order_atomic(payload JSONB)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid UUID := auth.uid();
  p JSONB;
  item JSONB;
  product_row RECORD;
  variant_row RECORD;
  rate_row RECORD;
  zone_row RECORD;
  cur TEXT := COALESCE(payload->>'currency','USD');
  payment payment_method := COALESCE((payload->>'payment_method')::payment_method,'CASH_ON_DELIVERY');
  subtotal_usd NUMERIC := 0;
  subtotal_syp NUMERIC := 0;
  subtotal NUMERIC := 0;
  delivery_usd NUMERIC := 0;
  delivery_syp NUMERIC := 0;
  delivery NUMERIC := 0;
  discount NUMERIC := 0;
  total NUMERIC := 0;
  rate NUMERIC := 1;
  order_id UUID;
  order_no TEXT;
  unit_usd NUMERIC;
  unit_syp NUMERIC;
  item_subtotal NUMERIC;
  item_total NUMERIC;
  qty NUMERIC;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'AUTH_REQUIRED'; END IF;
  IF cur NOT IN ('USD','SYP') THEN RAISE EXCEPTION 'UNSUPPORTED_CURRENCY'; END IF;

  SELECT * INTO rate_row FROM exchange_rates
   WHERE from_currency='USD' AND to_currency='SYP' AND effective_from <= NOW() AND (effective_to IS NULL OR effective_to > NOW())
   ORDER BY effective_from DESC LIMIT 1;
  IF cur='SYP' THEN
    IF NOT FOUND THEN RAISE EXCEPTION 'EXCHANGE_RATE_NOT_CONFIGURED'; END IF;
    rate := rate_row.rate;
  END IF;

  IF jsonb_array_length(COALESCE(payload->'items','[]'::jsonb)) = 0 THEN RAISE EXCEPTION 'EMPTY_CART'; END IF;

  FOR item IN SELECT * FROM jsonb_array_elements(payload->'items') LOOP
    qty := (item->>'quantity')::NUMERIC;
    IF qty <= 0 THEN RAISE EXCEPTION 'INVALID_QUANTITY'; END IF;
    SELECT * INTO product_row FROM products WHERE id=(item->>'product_id')::UUID AND is_active AND deleted_at IS NULL FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'PRODUCT_NOT_FOUND'; END IF;
    IF product_row.stock_quantity < qty THEN RAISE EXCEPTION 'INSUFFICIENT_STOCK'; END IF;
    unit_usd := product_row.base_price_usd;
    unit_syp := COALESCE(product_row.manual_syp_price, unit_usd * rate);
    IF (item ? 'variant_id') AND item->>'variant_id' IS NOT NULL THEN
      SELECT * INTO variant_row FROM product_variants WHERE id=(item->>'variant_id')::UUID AND product_id=product_row.id AND is_active FOR UPDATE;
      IF NOT FOUND OR variant_row.stock_quantity < qty THEN RAISE EXCEPTION 'VARIANT_UNAVAILABLE'; END IF;
      unit_usd := unit_usd + variant_row.price_modifier_usd;
      unit_syp := unit_syp + COALESCE(variant_row.price_modifier_syp, variant_row.price_modifier_usd * rate);
    END IF;
    item_subtotal := CASE WHEN cur='USD' THEN unit_usd*qty ELSE unit_syp*qty END;
    subtotal_usd := subtotal_usd + unit_usd*qty;
    subtotal_syp := subtotal_syp + unit_syp*qty;
    subtotal := subtotal + item_subtotal;
  END LOOP;

  IF payload->>'delivery_zone_id' IS NOT NULL THEN
    SELECT * INTO zone_row FROM delivery_zones WHERE id=(payload->>'delivery_zone_id')::UUID AND is_active;
    IF NOT FOUND THEN RAISE EXCEPTION 'DELIVERY_ZONE_NOT_FOUND'; END IF;
    delivery_usd := zone_row.fee_usd;
    delivery_syp := COALESCE(zone_row.fee_syp, delivery_usd*rate);
    delivery := CASE WHEN cur='USD' THEN delivery_usd ELSE delivery_syp END;
  END IF;

  -- Coupon calculation is intentionally server-side; extend this block when coupon validation rules are enabled.
  total := subtotal + delivery - discount;
  order_no := 'SC-' || to_char(NOW(),'YYYYMMDDHH24MISS') || '-' || upper(substr(encode(gen_random_bytes(3),'hex'),1,6));

  INSERT INTO orders(order_number,user_id,currency,subtotal,discount,delivery_fee,tax,total,subtotal_usd,subtotal_syp,discount_usd,discount_syp,delivery_usd,delivery_syp,total_usd,total_syp,exchange_rate_used,exchange_rate_id,payment_method,shipping_address_snapshot,customer_notes)
  VALUES(order_no,uid,cur,subtotal,discount,delivery,0,total,subtotal_usd,subtotal_syp,0,0,delivery_usd,delivery_syp,subtotal_usd+delivery_usd,subtotal_syp+delivery_syp,rate,CASE WHEN cur='SYP' THEN rate_row.id ELSE NULL END,payment,COALESCE(payload->'shipping_address','{}'::jsonb),payload->>'customer_notes')
  RETURNING id INTO order_id;

  FOR item IN SELECT * FROM jsonb_array_elements(payload->'items') LOOP
    qty := (item->>'quantity')::NUMERIC;
    SELECT * INTO product_row FROM products WHERE id=(item->>'product_id')::UUID;
    unit_usd := product_row.base_price_usd;
    unit_syp := COALESCE(product_row.manual_syp_price, unit_usd*rate);
    IF (item ? 'variant_id') AND item->>'variant_id' IS NOT NULL THEN
      SELECT * INTO variant_row FROM product_variants WHERE id=(item->>'variant_id')::UUID;
      unit_usd := unit_usd + variant_row.price_modifier_usd;
      unit_syp := unit_syp + COALESCE(variant_row.price_modifier_syp, variant_row.price_modifier_usd*rate);
    END IF;
    item_total := CASE WHEN cur='USD' THEN unit_usd*qty ELSE unit_syp*qty END;
    INSERT INTO order_items(order_id,product_id,variant_id,product_name_snapshot,sku_snapshot,unit_price,quantity,subtotal,total,currency,unit_price_usd,unit_price_syp,selected_options,custom_message)
    VALUES(order_id,product_row.id,(item->>'variant_id')::UUID,product_row.name_ar,product_row.sku,CASE WHEN cur='USD' THEN unit_usd ELSE unit_syp END,qty,item_total,item_total,cur,unit_usd,unit_syp,COALESCE(item->'selected_options','{}'::jsonb),item->>'custom_message');
    UPDATE products SET stock_quantity=stock_quantity-qty, updated_at=NOW() WHERE id=product_row.id;
    INSERT INTO inventory_movements(product_id,type,quantity,reference_type,reference_id,note) VALUES(product_row.id,'SALE',qty,'ORDER',order_id,'Checkout');
  END LOOP;
  INSERT INTO order_status_history(order_id,new_status,changed_by,note) VALUES(order_id,'NEW',uid,'Order created');
  RETURN jsonb_build_object('order_id',order_id,'order_number',order_no,'currency',cur,'subtotal',subtotal,'delivery_fee',delivery,'discount',discount,'total',total,'total_usd',subtotal_usd+delivery_usd,'total_syp',subtotal_syp+delivery_syp,'exchange_rate_used',rate);
END;
$$;
REVOKE ALL ON FUNCTION public.create_order_atomic(JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_order_atomic(JSONB) TO authenticated;

-- Optional initial rate: replace 12500 with the rate you actually want before production.
INSERT INTO exchange_rates(from_currency,to_currency,rate)
SELECT 'USD','SYP',12500
WHERE NOT EXISTS (SELECT 1 FROM exchange_rates WHERE from_currency='USD' AND to_currency='SYP');
