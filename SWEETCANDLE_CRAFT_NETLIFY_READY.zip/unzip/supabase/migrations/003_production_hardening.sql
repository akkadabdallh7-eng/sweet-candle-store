-- SWEETCANDLE.CRAFT production hardening
-- Run after 001_initial.sql and 002_phase2_backend.sql.

-- Normalize legacy uppercase roles into the canonical roles created by migration 002.
DO $$
DECLARE legacy RECORD; canonical UUID;
BEGIN
  FOR legacy IN SELECT * FROM (VALUES
    ('OWNER','Owner'),('ADMIN','Admin'),('ORDERS_MANAGER','Orders Manager'),('PRODUCTS_MANAGER','Products Manager'),('MARKETING_MANAGER','Marketing Manager')
  ) AS x(old_name,new_name) LOOP
    SELECT id INTO canonical FROM roles WHERE name=legacy.new_name LIMIT 1;
    IF canonical IS NOT NULL THEN
      UPDATE user_roles ur SET role_id=canonical WHERE ur.role_id=(SELECT id FROM roles WHERE name=legacy.old_name LIMIT 1);
      DELETE FROM roles WHERE name=legacy.old_name;
    END IF;
  END LOOP;
END $$;

-- Create a customer profile automatically after Supabase Auth signup.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles(id, display_name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.email), NEW.email)
  ON CONFLICT (id) DO UPDATE SET email=EXCLUDED.email;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Public catalog/settings reads.
DO $$ BEGIN
  CREATE POLICY products_public_select ON products FOR SELECT
    USING (is_active = TRUE AND deleted_at IS NULL);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY categories_public_select ON categories FOR SELECT USING (is_active = TRUE);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY occasions_public_select ON occasions FOR SELECT USING (is_active = TRUE);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_images_public_select ON product_images FOR SELECT
    USING (EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_videos_public_select ON product_videos FOR SELECT
    USING (EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_variants_public_select ON product_variants FOR SELECT
    USING (is_active=TRUE AND EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_options_public_select ON product_options FOR SELECT
    USING (is_active=TRUE AND EXISTS (SELECT 1 FROM products p WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_option_values_public_select ON product_option_values FOR SELECT
    USING (is_active=TRUE AND EXISTS (SELECT 1 FROM product_options po JOIN products p ON p.id=po.product_id WHERE po.id=option_id AND po.is_active=TRUE AND p.is_active=TRUE AND p.deleted_at IS NULL));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_categories_public_select ON product_categories FOR SELECT
    USING (EXISTS (SELECT 1 FROM products p JOIN categories c ON c.id=category_id WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL AND c.is_active=TRUE));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY product_occasions_public_select ON product_occasions FOR SELECT
    USING (EXISTS (SELECT 1 FROM products p JOIN occasions o ON o.id=occasion_id WHERE p.id=product_id AND p.is_active=TRUE AND p.deleted_at IS NULL AND o.is_active=TRUE));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY exchange_rates_public_select ON exchange_rates FOR SELECT
    USING (from_currency='USD' AND to_currency='SYP' AND effective_from <= NOW() AND (effective_to IS NULL OR effective_to > NOW()));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY currencies_public_select ON currencies FOR SELECT USING (is_active=TRUE);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY currency_settings_public_select ON currency_settings FOR SELECT USING (TRUE);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY store_settings_public_select ON store_settings FOR SELECT USING (TRUE);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Admin access to operational tables.
DO $$ BEGIN
  CREATE POLICY orders_admin_all ON orders FOR ALL
    USING (has_any_role(ARRAY['Owner','Admin','Orders Manager']))
    WITH CHECK (has_any_role(ARRAY['Owner','Admin','Orders Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY order_items_admin_all ON order_items FOR ALL
    USING (has_any_role(ARRAY['Owner','Admin','Orders Manager']))
    WITH CHECK (has_any_role(ARRAY['Owner','Admin','Orders Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY order_status_history_admin_all ON order_status_history FOR ALL
    USING (has_any_role(ARRAY['Owner','Admin','Orders Manager']))
    WITH CHECK (has_any_role(ARRAY['Owner','Admin','Orders Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY profiles_admin_select ON profiles FOR SELECT
    USING (id=auth.uid() OR has_any_role(ARRAY['Owner','Admin','Orders Manager','Marketing Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY inventory_admin_all ON inventory_movements FOR ALL
    USING (has_any_role(ARRAY['Owner','Admin','Products Manager','Orders Manager']))
    WITH CHECK (has_any_role(ARRAY['Owner','Admin','Products Manager','Orders Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY reviews_admin_all ON reviews FOR ALL
    USING (has_any_role(ARRAY['Owner','Admin','Marketing Manager']))
    WITH CHECK (has_any_role(ARRAY['Owner','Admin','Marketing Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY coupons_admin_all ON coupons FOR ALL
    USING (has_any_role(ARRAY['Owner','Admin','Marketing Manager']))
    WITH CHECK (has_any_role(ARRAY['Owner','Admin','Marketing Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY delivery_zones_admin_all ON delivery_zones FOR ALL
    USING (has_any_role(ARRAY['Owner','Admin','Orders Manager']))
    WITH CHECK (has_any_role(ARRAY['Owner','Admin','Orders Manager']));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Secure status changes: every update writes a history record.
CREATE OR REPLACE FUNCTION public.log_order_status_change()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO order_status_history(order_id, old_status, new_status, changed_by, note)
    VALUES (NEW.id, OLD.status, NEW.status, auth.uid(), 'Status changed from admin/customer workflow');
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS trg_order_status_history ON orders;
CREATE TRIGGER trg_order_status_history
AFTER UPDATE OF status ON orders
FOR EACH ROW EXECUTE FUNCTION public.log_order_status_change();

-- Initial currency/settings rows.
INSERT INTO currencies(code,name_ar,name_en,symbol,decimal_places,position,is_default,is_active)
VALUES
 ('USD','الدولار الأمريكي','US Dollar','$',2,'before',TRUE,TRUE),
 ('SYP','الليرة السورية الجديدة','Syrian Pound','ل.س',0,'after',FALSE,TRUE)
ON CONFLICT(code) DO UPDATE SET is_active=EXCLUDED.is_active;

INSERT INTO currency_settings(default_currency,rounding_mode,rounding_precision,allow_customer_currency_switch,show_dual_currency)
SELECT 'USD','HALF_UP',0,TRUE,FALSE
WHERE NOT EXISTS (SELECT 1 FROM currency_settings);

INSERT INTO store_settings(store_name,tagline,phone,whatsapp,instagram)
SELECT 'SWEETCANDLE.CRAFT','كل شمعة… تحكي قصة ♡','0994027648','+963994027648','https://www.instagram.com/sweetcandle.craft/'
WHERE NOT EXISTS (SELECT 1 FROM store_settings);
