# SWEETCANDLE.CRAFT — Final App Package

متجر Luxury عربي RTL مبني بـ Next.js + Supabase، مع PWA، حسابات العملاء، السلة، Checkout ذري، إدارة الطلبات، المخزون، العملات USD/SYP، وسعر صرف محفوظ داخل كل طلب.

## ما يعمل الآن
- واجهة المتجر العربية RTL ومتجاوبة.
- PWA قابلة للتثبيت على الهاتف والكمبيوتر.
- المنتجات والتصنيفات والمناسبات قابلة للقراءة من Supabase مع fallback محلي عند عدم الإعداد.
- حسابات العملاء عبر Supabase Auth.
- سلة محلية.
- Checkout حقيقي عبر RPC ذرية مع تثبيت سعر الصرف.
- خصم المخزون وسجل حركة المخزون.
- طلبات العملاء وحالات الطلب.
- لوحة إدارة محمية بالصلاحيات.
- إدارة سعر صرف USD/SYP.
- WhatsApp وInstagram.

## التثبيت
```bash
npm install
cp .env.example .env.local
npm run build
npm start
```

## Supabase — بالترتيب
1. `supabase/migrations/001_initial.sql`
2. `supabase/migrations/002_phase2_backend.sql`
3. `supabase/migrations/003_production_hardening.sql`
4. اختياري: `supabase/seed/001_catalog.sql`
5. بعد إنشاء حساب المالك: انسخ UUID إلى `supabase/seed/002_owner_assignment.sql` وشغله.

## Environment
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `NEXT_PUBLIC_WHATSAPP`
- `NEXT_PUBLIC_INSTAGRAM`

لا تضع `SUPABASE_SERVICE_ROLE_KEY` في الواجهة أو Git.

## النشر
جاهز للنشر على Vercel أو أي استضافة Node.js متوافقة مع Next.js. أضف متغيرات البيئة نفسها، ثم اربط نطاقك `sweetcandlecraft.com`.

## ملاحظات إطلاق حقيقية
- استبدل صور المنتجات التجريبية بصورك الحقيقية داخل Supabase Storage.
- راجع سعر الصرف قبل أول طلب حقيقي.
- أضف مناطق التوصيل ورسومها.
- فعّل مزود البريد/الإشعارات الذي تختاره.
- اختبر الطلب، المخزون، الصلاحيات والعملتين قبل فتح المتجر للجمهور.
