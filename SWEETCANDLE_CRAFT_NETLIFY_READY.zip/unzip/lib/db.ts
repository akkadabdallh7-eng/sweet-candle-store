import { supabase } from './supabase';

export async function getCatalog() {
  if (!supabase) return { products: [], categories: [], occasions: [], rate: 0 };
  const [{ data: products }, { data: categories }, { data: occasions }, { data: rates }] = await Promise.all([
    supabase.from('products').select('*,product_images(*),product_variants(*),product_options(*,product_option_values(*))').eq('is_active', true).is('deleted_at', null).order('created_at', { ascending: false }),
    supabase.from('categories').select('*').eq('is_active', true).order('sort_order'),
    supabase.from('occasions').select('*').eq('is_active', true).order('sort_order'),
    supabase.from('exchange_rates').select('*').eq('from_currency','USD').eq('to_currency','SYP').order('effective_from',{ascending:false}).limit(1)
  ]);
  return { products: products ?? [], categories: categories ?? [], occasions: occasions ?? [], rate: Number(rates?.[0]?.rate ?? 0) };
}
