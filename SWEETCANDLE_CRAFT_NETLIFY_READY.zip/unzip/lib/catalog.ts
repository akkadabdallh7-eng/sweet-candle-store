import { Product } from './types';

export const products: Product[] = [
  { id:'p1', slug:'golden-rose', name:'شمعة الورد الذهبي', description:'شمعة عطرية فاخرة بتفاصيل ناعمة وتغليف يليق بالهدايا المميزة.', category:'شموع معطرة', occasions:['ذكرى خاصة','عيد الميلاد'], image:'/brand/logo.png', priceUSD:18, featured:true, bestseller:true, scents:['ورد','فانيلا'], colors:['ذهبي','كريمي'], stock:14 },
  { id:'p2', slug:'graduation-bouquet', name:'باقة شموع التخرج', description:'باقة احتفالية مصممة لتوثيق لحظة النجاح بتفاصيل دافئة.', category:'باقات الشموع', occasions:['التخرج','النجاح'], image:'/brand/logo.png', priceUSD:28, discount:10, featured:true, bestseller:true, scents:['فانيلا','مسك'], colors:['ذهبي','أبيض'], stock:8 },
  { id:'p3', slug:'bride-candle', name:'شمعة العروس', description:'تصميم أنيق للعروس، مناسب للهدايا والتوزيعات والاحتفال.', category:'شموع العروس', occasions:['العروس','الزواج','الخطوبة'], image:'/brand/logo.png', priceUSD:22, featured:true, scents:['ياسمين','فانيلا'], colors:['أبيض','ذهبي'], stock:10 },
  { id:'p4', slug:'success-gift', name:'هدية النجاح', description:'هدية صغيرة بفكرة كبيرة، قابلة للتخصيص بالاسم والرسالة.', category:'هدايا النجاح', occasions:['النجاح','التخرج'], image:'/brand/logo.png', priceUSD:16, discount:10, bestseller:true, scents:['لافندر','فانيلا'], colors:['وردي','كريمي'], stock:22 },
  { id:'p5', slug:'custom-candle', name:'شمعة مخصصة', description:'اصنع شمعتك الخاصة: الاسم، اللون، الرائحة، الحجم والرسالة.', category:'منتجات مخصصة', occasions:['ذكرى خاصة','عيد الميلاد'], image:'/brand/logo.png', priceUSD:0, featured:true, scents:['حسب الطلب'], colors:['حسب الطلب'], stock:999 },
  { id:'p6', slug:'newborn-gift', name:'هدية المولود', description:'تفاصيل لطيفة وناعمة لاستقبال المولود بطريقة لا تُنسى.', category:'هدايا خاصة', occasions:['المواليد'], image:'/brand/logo.png', priceUSD:20, scents:['بودرة أطفال','فانيلا'], colors:['وردي','أزرق'], stock:12 }
];

export const categories = ['شموع معطرة','شموع العروس','شموع التخرج','هدايا النجاح','باقات الشموع','توزيعات المناسبات','هدايا خاصة','منتجات مخصصة'];
export const occasions = ['التخرج','الخطوبة','الزواج','العروس','أعياد الميلاد','النجاح','ذكرى خاصة','المناسبات الدينية','المواليد'];
