export type CurrencyCode = 'USD' | 'SYP';
export type Product = {
  id: string;
  slug: string;
  name: string;
  description: string;
  category: string;
  occasions: string[];
  image: string;
  priceUSD: number;
  priceSYP?: number;
  featured?: boolean;
  bestseller?: boolean;
  discount?: number;
  scents: string[];
  colors: string[];
  stock: number;
};
