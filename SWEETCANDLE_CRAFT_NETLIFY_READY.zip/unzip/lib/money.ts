import { CurrencyCode } from './types';

export const DEFAULT_EXCHANGE_RATE = 12500;

export function convertUSD(amountUSD: number, currency: CurrencyCode, rate = DEFAULT_EXCHANGE_RATE) {
  return currency === 'USD' ? amountUSD : amountUSD * rate;
}

export function formatMoney(amountUSD: number, currency: CurrencyCode, rate = DEFAULT_EXCHANGE_RATE) {
  if (currency === 'USD') return `$${amountUSD.toFixed(2)}`;
  return `${Math.round(amountUSD * rate).toLocaleString('en-US')} ل.س`;
}
