# SWEETCANDLE.CRAFT — قائمة الإطلاق الفعلي

## 1) Supabase
- أنشئ مشروع Supabase جديد.
- شغّل `supabase/migrations/001_initial.sql` ثم `002_phase2_backend.sql`.
- أنشئ مستخدمًا في Authentication ثم اربطه بدور Owner في `user_roles`.
- فعّل Email Auth أو مزود تسجيل الدخول الذي تختاره.

## 2) البيئة
انسخ `.env.example` إلى `.env.local` وضع: 
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## 3) بيانات المتجر
- أضف المنتجات الحقيقية والصور إلى Storage/Database.
- غيّر سعر الصرف الابتدائي في جدول `exchange_rates`.
- أضف مناطق التوصيل.
- راجع طرق الدفع.

## 4) الاختبار
- إنشاء حساب.
- تسجيل الدخول.
- إضافة منتج للسلة.
- اختيار USD/SYP.
- إتمام طلب تجريبي.
- التأكد من خصم المخزون.
- تغيير سعر الصرف ثم التأكد أن الطلب السابق لم يتغير.
- اختبار صلاحيات Owner/Orders Manager/Products Manager.

## 5) النشر
```bash
npm install
npm run build
npm start
```
ثم انشره على Vercel وأضف متغيرات البيئة نفسها.

## 6) النطاق
اربط النطاق `sweetcandlecraft.com` من لوحة DNS لدى مزود النطاق، وأضف الدومين إلى Vercel.

## 7) PWA
الموقع متجاوب وPWA-ready. على الهاتف يمكن تثبيته من المتصفح.

> لا تضع Service Role Key في الواجهة أو Git. استخدم فقط ANON key في العميل.
